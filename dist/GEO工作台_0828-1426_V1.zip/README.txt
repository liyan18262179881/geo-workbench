GEO 工作台 · 完整项目（合并版）

已将「GEO工作台」与「GEO项目」合并为单一客户。

启动：双击「启动.command」或运行 python3 server.py
访问：http://localhost:8765
侧栏客户：GEO工作台（约 20 个关键词）

依赖：pip3 install anthropic openai
